using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Logros.Models;

public class Producto
{
    [Key]
    public int? IdProducto { get; set; }
    public string? Nombre { get; set; }
    public string? Marca { get; set; }
    public decimal Precio { get; set; }
}