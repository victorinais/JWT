using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Logros.Models;

namespace Logros.Data;

public class LogrosDbContext : DbContext
{
    public LogrosDbContext(DbContextOptions<LogrosDbContext> options): base(options){
    }

    public DbSet<Usuario> Usuarios { get; set; }
    public DbSet<Producto> Productos { get; set; }
}