using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Logros.Custom;
using Logros.Models;
using Logros.Models.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Logros.Data;

namespace Logros.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class ProductoController : ControllerBase
    {
       private readonly LogrosDbContext _logrosDbContext;
       public ProductoController(LogrosDbContext logrosDbContext)
       {
            _logrosDbContext = logrosDbContext;
       }

       [HttpGet]
       [Route("Lista")]
       public async Task<IActionResult> Lista()
       {
        var lista = await _logrosDbContext.Productos.ToListAsync();
        return StatusCode(StatusCodes.Status200OK, new { value = lista});
       }
    }
}