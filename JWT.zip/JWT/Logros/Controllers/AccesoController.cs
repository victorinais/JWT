using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Logros.Custom;
using Logros.Models;
using Logros.Models.DTOs;
using Microsoft.AspNetCore.Authorization;
using Logros.Data;

namespace Logros.Controllers
{
    [Route("api/[controller]")]
    [AllowAnonymous]
    [ApiController]
    public class AccesoController : ControllerBase
    {
        private readonly LogrosDbContext _logrosDbContext;
        private readonly Utilidades _utilidades;

        public AccesoController(LogrosDbContext logrosDbContext, Utilidades utilidades)
        {
            _logrosDbContext = logrosDbContext;
            _utilidades = utilidades;
        }

        [HttpPost]
        [Route("Registrarse")]
        public async Task<IActionResult> Registrarse(UsuarioDTO objeto)
        {
            var modeloUsuario = new Usuario
            {
                Nombre = objeto.Nombre,
                Correo = objeto.Correo,
                Clave =  _utilidades.encriptarSHA256(objeto.Clave)
            };

            await _logrosDbContext.Usuarios.AddAsync(modeloUsuario);
            await _logrosDbContext.SaveChangesAsync();

            if(modeloUsuario.IdUsuario != 0)
                return StatusCode(StatusCodes.Status200OK, new { isSuccess = true });
            else
                return StatusCode(StatusCodes.Status200OK, new { isSuccess = false });
        }
        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login(LoginDTO objeto)
        {
            var usuarioEncontrado = await _logrosDbContext.Usuarios.Where(u => 
                u.Correo == objeto.Correo &&
                u.Clave == _utilidades.encriptarSHA256(objeto.Clave)
                ).FirstOrDefaultAsync();
            
            if(usuarioEncontrado == null)
                return StatusCode(StatusCodes.Status200OK, new { isSuccess = false, token = "" });
            else
                return StatusCode(StatusCodes.Status200OK, new { isSuccess = true, token = _utilidades.generarJWT(usuarioEncontrado)});
        }
    }
}